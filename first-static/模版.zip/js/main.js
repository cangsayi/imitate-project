var h = 10146, m = 39, sec =28, i=true;
var hour = document.getElementById("hour");
var min = document.getElementById("min");
var second = document.getElementById("second");

var nav = document.getElementsByTagName("nav")[0];
var lis = nav.getElementsByTagName("li");

window.onload = function(){
window.onscroll =function(){


//alert(nav.classList);
        
    if(window.scrollY > 99)                                    //固定导航栏
    {
        $('nav').addClass("fixed");
    }else{
        $('nav').removeClass("fixed");
    }
    if(window.scrollY >100){
        $('nav').addClass("awake");
    }else {
        $('nav').removeClass("awake");
    }

    if(window.scrollY >= 700){   
        lis[0].classList.remove("active");                       //导航到小项的地方添加active类高亮显示;
        lis[1].classList.add("active");
    }else {
        lis[1].classList.remove("active");
        lis[0].classList.add("active");
    }
    if(window.scrollY >=2190){
        lis[1].classList.remove("active");
        lis[2].classList.add("active");
    } else {
        lis[2].classList.remove("active");
    }
    if(window.scrollY >=3390){
        lis[2].classList.remove("active");
        lis[3].classList.add("active");
    }else{
        lis[3].classList.remove("active");
    }
    if(window.scrollY >=6860){
        lis[3].classList.remove("active");
        lis[4].classList.add("active");
    }else {
        lis[4].classList.remove("active");
    }
    if(window.scrollY >=9290){
        lis[4].classList.remove("active");
        lis[5].classList.add("active");
    }else {
        lis[5].classList.remove("active");
    }

   if(window.scrollY >=8100){
       if(i == true){
           i=false;
           time = setInterval(function(){
            h+=500;
            m+=25;
            sec+=2;
              hour.innerHTML = h;
              min.innerHTML = m;
              second.innerHTML = sec;
  
          if(h >=34146){
              clearInterval(time);
          }
           },100);
       }
   }
    
   // console.log(window.scrollY);
}
}

var $list = $(".all-content");
var $right = $("#right");
var timer;
var l=0;	
	
	function slideLeft(){						//动画实现函数；
		 l++;
        if(!$list.is(":animated")){
			if(l==5){
				    $list.animate({left:0,});
					l=1;
			  }
            $list.stop(true,true).animate({left:'-='+360},"normal");
              
            }
    }
    
    
	
	
$(function(){										//可以衔接的轮播图，难点是一个周期之后，衔接的处理。
									
	
    $right.click(function(){				//点击触发;
       slideLeft();
    });
   
 
 
    /*
 
timer=setInterval(function(){                       //load事件默认;  
		slideLeft();
	},3000);
	$(".animation").mouseenter(function(){		//进入时清除默认和事件的定时器;
			clearInterval(timer);
	}).mouseleave(function(){
		timer = setInterval(function(){				//离开时，执行定时器动画；
		slideLeft();
	},3000);
	});         */    


});